﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Gestor_Gym
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Lerr archivo configuracion
            ConnectionStringSettings setting = ConfigurationManager.ConnectionStrings["GimnasioConnectionString"];
            //Conectarme con bbdd
            SqlConnection conn = new SqlConnection(setting.ConnectionString);
            SqlCommand cmdNuevoUsuariosp = new SqlCommand("Gimnasio.dbo.INSERTARUSUARIO", conn);
            cmdNuevoUsuariosp.CommandType = CommandType.StoredProcedure;




            cmdNuevoUsuariosp.Parameters.Add(new SqlParameter("@IDUsuario", SqlDbType.Int));
            cmdNuevoUsuariosp.Parameters["@IDUsuario"].Value = Convert.ToInt32(id.Text);

            cmdNuevoUsuariosp.Parameters.Add(new SqlParameter("@Nombre", SqlDbType.Text));
            cmdNuevoUsuariosp.Parameters["@Nombre"].Value = nombre.Text;

            cmdNuevoUsuariosp.Parameters.Add(new SqlParameter("@Apellidos", SqlDbType.Text));
            cmdNuevoUsuariosp.Parameters["@Apellidos"].Value = apellidos.Text;

            cmdNuevoUsuariosp.Parameters.Add(new SqlParameter("@DNI", SqlDbType.VarChar,9));
            cmdNuevoUsuariosp.Parameters["@DNI"].Value = dni.Text;

            cmdNuevoUsuariosp.Parameters.Add(new SqlParameter("@Edad", SqlDbType.Int));
            cmdNuevoUsuariosp.Parameters["@Edad"].Value = Convert.ToInt32 (edad.Text);

            cmdNuevoUsuariosp.Parameters.Add(new SqlParameter("@IBAN", SqlDbType.VarChar,45));
            cmdNuevoUsuariosp.Parameters["@IBAN"].Value = iban.Text;

            cmdNuevoUsuariosp.Parameters.Add(new SqlParameter("@Email", SqlDbType.VarChar, 45));
            cmdNuevoUsuariosp.Parameters["@Email"].Value = email.Text;

            cmdNuevoUsuariosp.Parameters.Add(new SqlParameter("@Direccion", SqlDbType.VarChar, 45));
            cmdNuevoUsuariosp.Parameters["@Direccion"].Value = direccion.Text;

            cmdNuevoUsuariosp.Parameters.Add(new SqlParameter("@Tipos_Usuario", SqlDbType.Int));
            cmdNuevoUsuariosp.Parameters["@Tipos_Usuario"].Value = Convert.ToInt32(tipo_usuario.Text);

            cmdNuevoUsuariosp.Parameters.Add(new SqlParameter("@Username", SqlDbType.VarChar, 45));
            cmdNuevoUsuariosp.Parameters["@Username"].Value = username.Text;

            cmdNuevoUsuariosp.Parameters.Add(new SqlParameter("@Passaword", SqlDbType.VarChar, 45));
            cmdNuevoUsuariosp.Parameters["@Passaword"].Value = password.Text;

            try
            {
                //abrir la conexion
                conn.Open();

                cmdNuevoUsuariosp.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("no se ha podido insertar nuevo CO" + ex.Message);
            }


            finally
            {
                conn.Close();

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
