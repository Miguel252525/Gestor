﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace Gestor_Gym
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            CargarUsuario();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CargarUsuario();
        }

        private void CargarUsuario()
        {
            //Leer archivo configuracion
            ConnectionStringSettings setting = ConfigurationManager.ConnectionStrings["GimnasioConnectionString"];// Leer la coneection
                                                                                                                  //Conectarme con bbdd
            SqlConnection conn = new SqlConnection(setting.ConnectionString);//Lee pasamos lo que hemos preparado
                                                                             //Seleccionar los campos de operacion
            string query = "SELECT IDUsuario, nombre, apellidos, edad, email FROM Gimnasio.dbo.Tabla_Usuarios";
            SqlCommand cmdVerCO = new SqlCommand(query, conn); //Ver el campo de operacion
                                                               //Mostrarlos en el grid
            try
            {
                //Abrir la conexión
                conn.Open();
                //Ejecutar comando
                SqlDataReader rdr = cmdVerCO.ExecuteReader();

                DataTable dt = new DataTable();
                dt.Load(rdr); //Cargando una tabla donde le pasamos el DataReader

                this.dataGridView1.DataSource = dt;

                //Cierro el datareader, cerrara también la conexion
                rdr.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se ha podido conectar" + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form frm = new Form1();
            frm.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
