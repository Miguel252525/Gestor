﻿namespace Gestor_Gym
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.nombre = new System.Windows.Forms.TextBox();
            this.apellidos = new System.Windows.Forms.TextBox();
            this.dni = new System.Windows.Forms.TextBox();
            this.edad = new System.Windows.Forms.TextBox();
            this.iban = new System.Windows.Forms.TextBox();
            this.email = new System.Windows.Forms.TextBox();
            this.direccion = new System.Windows.Forms.TextBox();
            this.Nombres = new System.Windows.Forms.Label();
            this.Apellido = new System.Windows.Forms.Label();
            this.DNIs = new System.Windows.Forms.Label();
            this.Edads = new System.Windows.Forms.Label();
            this.IBANs = new System.Windows.Forms.Label();
            this.Emails = new System.Windows.Forms.Label();
            this.Direccions = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label = new System.Windows.Forms.Label();
            this.id = new System.Windows.Forms.TextBox();
            this.tipo_usuario = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.username = new System.Windows.Forms.TextBox();
            this.password = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // nombre
            // 
            this.nombre.Location = new System.Drawing.Point(282, 44);
            this.nombre.Name = "nombre";
            this.nombre.Size = new System.Drawing.Size(295, 22);
            this.nombre.TabIndex = 0;
            // 
            // apellidos
            // 
            this.apellidos.Location = new System.Drawing.Point(282, 95);
            this.apellidos.Name = "apellidos";
            this.apellidos.Size = new System.Drawing.Size(295, 22);
            this.apellidos.TabIndex = 1;
            // 
            // dni
            // 
            this.dni.Location = new System.Drawing.Point(282, 149);
            this.dni.Name = "dni";
            this.dni.Size = new System.Drawing.Size(295, 22);
            this.dni.TabIndex = 2;
            // 
            // edad
            // 
            this.edad.Location = new System.Drawing.Point(282, 203);
            this.edad.Name = "edad";
            this.edad.Size = new System.Drawing.Size(295, 22);
            this.edad.TabIndex = 3;
            this.edad.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // iban
            // 
            this.iban.Location = new System.Drawing.Point(282, 252);
            this.iban.Name = "iban";
            this.iban.Size = new System.Drawing.Size(295, 22);
            this.iban.TabIndex = 4;
            // 
            // email
            // 
            this.email.Location = new System.Drawing.Point(282, 304);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(295, 22);
            this.email.TabIndex = 5;
            // 
            // direccion
            // 
            this.direccion.Location = new System.Drawing.Point(282, 354);
            this.direccion.Name = "direccion";
            this.direccion.Size = new System.Drawing.Size(295, 22);
            this.direccion.TabIndex = 6;
            // 
            // Nombres
            // 
            this.Nombres.AutoSize = true;
            this.Nombres.Location = new System.Drawing.Point(175, 49);
            this.Nombres.Name = "Nombres";
            this.Nombres.Size = new System.Drawing.Size(58, 17);
            this.Nombres.TabIndex = 7;
            this.Nombres.Text = "Nombre";
            // 
            // Apellido
            // 
            this.Apellido.AutoSize = true;
            this.Apellido.Location = new System.Drawing.Point(175, 101);
            this.Apellido.Name = "Apellido";
            this.Apellido.Size = new System.Drawing.Size(65, 17);
            this.Apellido.TabIndex = 8;
            this.Apellido.Text = "Apellidos";
            // 
            // DNIs
            // 
            this.DNIs.AutoSize = true;
            this.DNIs.Location = new System.Drawing.Point(175, 152);
            this.DNIs.Name = "DNIs";
            this.DNIs.Size = new System.Drawing.Size(31, 17);
            this.DNIs.TabIndex = 9;
            this.DNIs.Text = "DNI";
            // 
            // Edads
            // 
            this.Edads.AutoSize = true;
            this.Edads.Location = new System.Drawing.Point(175, 203);
            this.Edads.Name = "Edads";
            this.Edads.Size = new System.Drawing.Size(41, 17);
            this.Edads.TabIndex = 10;
            this.Edads.Text = "Edad";
            // 
            // IBANs
            // 
            this.IBANs.AutoSize = true;
            this.IBANs.Location = new System.Drawing.Point(175, 252);
            this.IBANs.Name = "IBANs";
            this.IBANs.Size = new System.Drawing.Size(39, 17);
            this.IBANs.TabIndex = 11;
            this.IBANs.Text = "IBAN";
            // 
            // Emails
            // 
            this.Emails.AutoSize = true;
            this.Emails.Location = new System.Drawing.Point(175, 304);
            this.Emails.Name = "Emails";
            this.Emails.Size = new System.Drawing.Size(42, 17);
            this.Emails.TabIndex = 12;
            this.Emails.Text = "Email";
            // 
            // Direccions
            // 
            this.Direccions.AutoSize = true;
            this.Direccions.Location = new System.Drawing.Point(175, 354);
            this.Direccions.Name = "Direccions";
            this.Direccions.Size = new System.Drawing.Size(67, 17);
            this.Direccions.TabIndex = 13;
            this.Direccions.Text = "Direccion";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(651, 44);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(145, 74);
            this.button1.TabIndex = 14;
            this.button1.Text = "Añadir";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(840, 44);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(145, 73);
            this.button2.TabIndex = 15;
            this.button2.Text = "Salir";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Location = new System.Drawing.Point(185, 9);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(21, 17);
            this.label.TabIndex = 16;
            this.label.Text = "ID";
            // 
            // id
            // 
            this.id.Location = new System.Drawing.Point(282, 9);
            this.id.Name = "id";
            this.id.Size = new System.Drawing.Size(295, 22);
            this.id.TabIndex = 17;
            // 
            // tipo_usuario
            // 
            this.tipo_usuario.Location = new System.Drawing.Point(282, 400);
            this.tipo_usuario.Name = "tipo_usuario";
            this.tipo_usuario.Size = new System.Drawing.Size(295, 22);
            this.tipo_usuario.TabIndex = 18;
            this.tipo_usuario.TextChanged += new System.EventHandler(this.textBox9_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(175, 400);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 17);
            this.label1.TabIndex = 21;
            this.label1.Text = "Tipo usuario";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.label4.Font = new System.Drawing.Font("Monotype Corsiva", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(651, 252);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(334, 74);
            this.label4.TabIndex = 25;
            this.label4.Text = "TheForceGym";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(175, 495);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 17);
            this.label3.TabIndex = 23;
            this.label3.Text = "Password";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(175, 449);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 17);
            this.label2.TabIndex = 22;
            this.label2.Text = "Username";
            // 
            // username
            // 
            this.username.Location = new System.Drawing.Point(282, 449);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(295, 22);
            this.username.TabIndex = 19;
            // 
            // password
            // 
            this.password.Location = new System.Drawing.Point(282, 495);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(295, 22);
            this.password.TabIndex = 20;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1033, 540);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.password);
            this.Controls.Add(this.username);
            this.Controls.Add(this.tipo_usuario);
            this.Controls.Add(this.id);
            this.Controls.Add(this.label);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Direccions);
            this.Controls.Add(this.Emails);
            this.Controls.Add(this.IBANs);
            this.Controls.Add(this.Edads);
            this.Controls.Add(this.DNIs);
            this.Controls.Add(this.Apellido);
            this.Controls.Add(this.Nombres);
            this.Controls.Add(this.direccion);
            this.Controls.Add(this.email);
            this.Controls.Add(this.iban);
            this.Controls.Add(this.edad);
            this.Controls.Add(this.dni);
            this.Controls.Add(this.apellidos);
            this.Controls.Add(this.nombre);
            this.Name = "Form1";
            this.Text = "Datos";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox nombre;
        private System.Windows.Forms.TextBox apellidos;
        private System.Windows.Forms.TextBox dni;
        private System.Windows.Forms.TextBox edad;
        private System.Windows.Forms.TextBox iban;
        private System.Windows.Forms.TextBox email;
        private System.Windows.Forms.TextBox direccion;
        private System.Windows.Forms.Label Nombres;
        private System.Windows.Forms.Label Apellido;
        private System.Windows.Forms.Label DNIs;
        private System.Windows.Forms.Label Edads;
        private System.Windows.Forms.Label IBANs;
        private System.Windows.Forms.Label Emails;
        private System.Windows.Forms.Label Direccions;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.TextBox id;
        private System.Windows.Forms.TextBox tipo_usuario;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox username;
        private System.Windows.Forms.TextBox password;
    }
}

