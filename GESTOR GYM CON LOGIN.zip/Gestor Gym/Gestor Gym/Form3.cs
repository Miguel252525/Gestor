﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestor_Gym
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Validar_Click(object sender, EventArgs e)
        {
            if (TXusuario.Text == "Alberto" && double.Parse(TXcontraseña.Text) == 1234) ;
            {
                MessageBox.Show("Bienvenidos a TheForceGym");
                Form2 llamar = new Form2();
                llamar.Show();
            }
        }
    }
}
